# ClinicFirst — Click Aarambh Healthcare Suite
Monorepo: frontend (Next.js PWA) and backend (Node/Express + MongoDB Atlas). See /docs for setup.
