Deploy frontend to Vercel, backend to Render/Heroku. Use MongoDB Atlas.
