MVP -> Offline sync -> POS -> Analytics
